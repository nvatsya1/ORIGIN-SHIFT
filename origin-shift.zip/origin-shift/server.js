"use strict";
const http = require("http"), fs = require("fs"), path = require("path");
const { analyze, callAnthropic, HttpError } = require("./lib/analyze");
const MAX_BODY = 100_000;

function createServer({ callModel, model, rateLimit = 10 } = {}) {
  const mdl = () => model || process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5";
  const call = callModel || (p => callAnthropic(p, { apiKey: process.env.ANTHROPIC_API_KEY, model: mdl() }));
  const hits = new Map();
  const send = (res, status, obj) => { res.writeHead(status, { "content-type": "application/json", "cache-control": "no-store" }); res.end(JSON.stringify(obj)); };
  return http.createServer(async (req, res) => {
    const url = (req.url || "").split("?")[0];
    try {
      if (req.method === "GET" && url === "/") { res.writeHead(200, { "content-type": "text/html; charset=utf-8" }); return res.end(fs.readFileSync(path.join(__dirname, "public", "index.html"))); }
      if (req.method === "GET" && url === "/api/health") return send(res, 200, { ok: true, liveConfigured: Boolean(callModel || process.env.ANTHROPIC_API_KEY), model: mdl() });
      if (url === "/api/analyze") {
        if (req.method !== "POST") throw new HttpError(405, "method_not_allowed", "Use POST.");
        const ip = req.socket.remoteAddress || "?", now = Date.now();
        const recent = (hits.get(ip) || []).filter(t => now - t < 60000);
        if (recent.length >= rateLimit) throw new HttpError(429, "rate_limited", "Too many requests. Wait a minute.");
        hits.set(ip, [...recent, now]);
        let size = 0; const chunks = [];
        for await (const c of req) { size += c.length; if (size > MAX_BODY) throw new HttpError(413, "input_too_large", "Request body too large."); chunks.push(c); }
        let body; try { body = JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch { throw new HttpError(400, "invalid_json", "Body is not valid JSON."); }
        return send(res, 200, { record: await analyze(body, { callModel: call, model: mdl() }) });
      }
      throw new HttpError(404, "not_found", "Not found.");
    } catch (e) {
      if (e instanceof HttpError) return send(res, e.status, { error: { code: e.code, message: e.message } });
      console.error("internal error:", e && e.name);   // never log transcripts or stacks with user text
      send(res, 500, { error: { code: "internal_error", message: "Something went wrong analyzing this audit." } });
    }
  });
}
module.exports = { createServer };
if (require.main === module) { const p = process.env.PORT || 3000; createServer().listen(p, () => console.log(`ORIGIN SHIFT on http://localhost:${p}  (live analysis ${process.env.ANTHROPIC_API_KEY ? "configured" : "NOT configured: demo/manual only"})`)); }
