# ORIGIN SHIFT
Belief-transition audit: how an AI conversation changed a stated position.

## Run
    ANTHROPIC_API_KEY=sk-... npm start      # http://localhost:3000   (Node >= 20, zero dependencies)
    npm test

Config (server-side only): `ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL` (default `claude-sonnet-5-5`, verify against current Anthropic docs), `PORT`.

## Modes
- **Live analysis**: `POST /api/analyze` → Anthropic Messages API → JSON validated server-side (excerpts must exist verbatim in your input; ids, relationships, origins, turn numbers and confidence math are enforced/recomputed by the server).
- **Demo mode**: fixed fictional example, client-side, labeled as such. No key needed.
- **Manual**: you tag evidence statuses yourself; nothing is sent anywhere.

## Storage
Browser localStorage only. No database, no sync. Live analysis sends your text to this server and then to Anthropic.

## Limits
Not verified: live calls against the real Anthropic API (see status report). No auth; in-memory per-IP rate limit (10/min). Single-file frontend; lineage is a timeline, not a graph.
